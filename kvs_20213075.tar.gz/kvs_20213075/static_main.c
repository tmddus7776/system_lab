#include "kvs.h"

int main()
{
	//kvs open
	kvs_t* kvs = open();
	if(!kvs) {
		printf("Failed to open kvs\n");
		return -1;
	}
	//file open
	FILE* fp = fopen("student.dat", "r");
	if(!fp) {
		printf("Failed to open file\n");
		return -1;
	}
	// 1) file read 
	char fkey[100];
	char* fvalue = (char*) malloc (sizeof(char));
	char* rvalue;
	printf("Put operation...\n");
	while(!feof(fp)) {
		if(!fscanf(fp, "%s %s\n", fkey, fvalue)) {
			printf("Failed to fscanf data\n");
			exit(-1);
		}
		put(kvs, fkey, fvalue);
	}
	printf("\n");
	fclose(fp);
	FILE* fp2 = fopen("student.dat", "r");
	if(!fp2) {
                printf("Failed to open file\n");
                return -1;
        }
	printf("Get operation...\n");
	while(!feof(fp2)) {
                if(!fscanf(fp2, "%s %s\n", fkey, fvalue)) {
                        printf("Failed to fscanf data\n");
                        exit(-1);
                }
		
		if(!(rvalue = get(kvs, fkey))) {
			printf("Failed to fscanf data\n");
			exit(-1);
		}
		printf("get: %s, %s\n", fkey, rvalue);
        }
	printf("\n");
	fclose(fp2);

	printf("Seek operarion...\n");

	seek(kvs);	
	close(kvs);



#if 0
	char key[100]; 
	char* value = (char*) malloc (sizeof(char)* 300);
	char* rvalue;

	strcpy(key, "Eunji");
	strcpy(value, "Seoul");

	if(put(kvs, key, value) < 0){
		printf("Failed to put data\n");
		exit(-1);
	}

#endif


	// 3. get for test 

	// 1) file read 
	// 2) get & compare return value with original vallue 

#if 0
	if(!(rvalue = get(kvs, key))){
		printf("Failed to get data\n");
		exit(-1);
	}

	printf("get: %s, %s\n", key, rvalue);
#endif

	// 4. print all items 
#if 0
	int nitems = seek(kvs);
	printf("%d items are found\n", nitems);


	// 5. close 
	close(kvs);
#endif
	
	return 0;
}
