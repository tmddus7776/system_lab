#include "kvs.h"

int put(kvs_t* kvs, const char* key, const char* value)
{
	printf("put: %s, %s\n", key, value);

	node_t* current = kvs->db;
	int len = kvs->items;

	node_t* tmp = (node_t*) malloc (sizeof(node_t));
	tmp->value = (char*) malloc (sizeof(char)*300);
	strcpy(tmp->key, key);
	strcpy(tmp->value, value);

	if(len == 0) {
		kvs->db = tmp;
		kvs->items++;
		return 0;
	}
	else {
		while(current->next != NULL) {
			current = current->next;
		}
		current->next = tmp;
		kvs->items++;
		return 0;
	}

	return 0;
}
