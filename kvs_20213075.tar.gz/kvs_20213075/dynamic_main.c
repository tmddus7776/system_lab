#include "kvs.h"
#include <dlfcn.h>

int main()
{
	void *handle;
	kvs_t* (*open)();
	int (*close)(kvs_t*);
	int (*put)(kvs_t*, const char*, const char*);
	char* (*get)(kvs_t*, const char*);
	int (*seek)(kvs_t*);
	char *error;

	handle = dlopen("./libkvs.so", RTLD_LAZY);
	if(!handle) {
		fprintf(stderr, "%s\n", dlerror());
		exit(1);
	}
	//open
	open = (kvs_t*(*)()) dlsym(handle, "open");
	if((error = dlerror()) != NULL) {
		fprintf(stderr, "%s\n", error);
		exit(1);
	}
	kvs_t* kvs = open();

	if(!kvs) {
		printf("Failed to open kvs\n");
		return -1;
	}
	
	//put
	put = (int(*)(kvs_t*, const char*, const char*)) dlsym(handle, "put");
	if((error = dlerror()) != NULL) {
                 fprintf(stderr, "%s\n", error);
                 exit(1);
         }

	//file open
	FILE* fp = fopen("student.dat", "r");
	if(!fp) {
		printf("Failed to open file\n");
		return -1;
	}

	char fkey[100];
	char* fvalue = (char*) malloc (sizeof(char)*300);
	char* rvalue;
	printf("Put operation...\n");
	while(!feof(fp)) {
		if(!fscanf(fp, "%s %s\n", fkey, fvalue)) {
			printf("Failed to fscanf data\n");
			exit(-1);
		}
		put(kvs, fkey, fvalue);
	}
	printf("\n");
	fclose(fp);

	//get
	get = (char*(*)(kvs_t*, const char*))dlsym(handle, "get");
	if((error = dlerror()) != NULL) {
                  fprintf(stderr, "%s\n", error);
                  exit(1);
        }

	FILE* fp2 = fopen("student.dat", "r");
	if(!fp2) {
                printf("Failed to open file\n");
                return -1;
        } 
	printf("Get operation...\n");
	while(!feof(fp2)) {
                if(!fscanf(fp2, "%s %s\n", fkey, fvalue)) {
                        printf("Failed to fscanf data\n");
                        exit(-1);
                }
		rvalue = get(kvs, fkey);
		
		if(!(rvalue = get(kvs, fkey))) {
			printf("Failed to fscanf data\n");
			exit(-1);
		}
		printf("get: %s, %s\n", fkey, rvalue);
        }
	printf("\n");
	fclose(fp2);

	
	printf("Seek operarion...\n");
	//seek
	seek = (int(*)(kvs_t*)) dlsym(handle, "seek");
	if((error = dlerror()) != NULL) {
                  fprintf(stderr, "%s\n", error);
                  exit(1);
        }
	seek(kvs);

	//close
	close = (int(*)(kvs_t*)) dlsym(handle, "close");
	if((error = dlerror()) != NULL) {
                  fprintf(stderr, "%s\n", error);
                  exit(1);
        }	
	close(kvs);	
	return 0;
}
