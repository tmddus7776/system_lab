#include "kvs.h"

char* get(kvs_t* kvs, const char* key)
{
	/* do program here */
	node_t* current = kvs->db;
	int len = kvs->items;

	char* value = (char*)malloc(sizeof(char)*300);

	if(!value){
		printf("Failed to malloc\n");
		return NULL;
	}
	for(int i=0; i<len; i++) {
		if(strcmp(current->key, key) == 0) {
			return current->value;
		}
		current = current->next;
	}

	strcpy(value, "dead");
	return value;

}
