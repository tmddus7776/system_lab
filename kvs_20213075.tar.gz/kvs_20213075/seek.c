#include "kvs.h"

int seek(kvs_t* kvs)
{
	node_t* head = kvs->db;
	node_t* start = (node_t*) malloc (sizeof(node_t));
	start = head;
	int len = kvs->items;
		
	char rkey[100];
	char* rvalue = (char*) malloc (sizeof(char)*300);
	strcpy(rkey, head->key);

	node_t* cur = (node_t*) malloc (sizeof(node_t));
	cur = head->next;
	int j = 0;
	
	for(int i=0; i<len-1; i++) {
		for(j = i+1; j<len; j++) {
			if(strcmp(head->key, cur->key) > 0) {
				strcpy(rkey, head->key);
				strcpy(rvalue, head->value);
				strcpy(head->key, cur->key);
				strcpy(head->value, cur->value);
				strcpy(cur->key, rkey);
				strcpy(cur->value, rvalue);
			}
			cur = cur->next;
		}
		head = head->next;
		cur = head->next;
	}
	for(int i=0; i<len; i++) {
		printf("(%s %s)\n", start->key, start->value);
		start = start->next;
	}
		
	return 0;
}
